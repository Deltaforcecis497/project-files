﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Executive_System.Data;
using webhoseio;

namespace Executive_System.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }
        public ActionResult BrowseView()
        {
            return View();
        }
        public ActionResult SmartPicks()
        {
            return View();
        }

        public async Task<IActionResult> ViewArticle()
        {
            var client = new WebhoseClient(token: "0d3a46c7-3e9e-4811-98e4-00a6c2d08ed9");
            var queryParams = new Dictionary<string, string>
            {
                { "q", "mobile alabama hospitals language:english"},
                { "sort", "relevancy"}
            };

            var output = await client.QueryAsync("filterWebContent", queryParams);

            //get article
            //package into model
            return PartialView();
        }
    }
}