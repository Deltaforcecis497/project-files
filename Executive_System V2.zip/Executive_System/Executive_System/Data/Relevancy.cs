﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Executive_System.Data
{
    public class Relevancy
    {
        public int relevancyId { get; set; }
        public string userId { get; set; }

        public int articleId { get; set; }

        public Boolean relevancy { get; set; }
    }
}
