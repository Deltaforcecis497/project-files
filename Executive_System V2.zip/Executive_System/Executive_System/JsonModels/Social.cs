﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Executive_System.JsonModels
{
    public class Social
    {
        public SocialEntry facebook { get; set; }
        public SocialEntry gplus { get; set; }
        public SocialEntry pinterest { get; set; }
        public SocialEntry linkedin { get; set; }
        public SocialEntry stumbledupon { get; set; }
        public SocialEntry vk { get; set; }
    }
}
