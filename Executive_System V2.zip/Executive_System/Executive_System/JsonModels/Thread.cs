﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Executive_System.JsonModels
{
    public class Thread
    {
    }
}
