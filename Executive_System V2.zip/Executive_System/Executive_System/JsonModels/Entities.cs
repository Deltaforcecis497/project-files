﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Executive_System.JsonModels
{
    public class Entities
    {
        public List<NameSentiment> persons { get; set; }
        public List<NameSentiment> organizations { get; set; }
        public List<NameSentiment> locations { get; set; }
    }
}
