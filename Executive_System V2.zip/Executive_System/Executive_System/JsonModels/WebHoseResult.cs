﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Executive_System.JsonModels
{
    public class WebHoseResult
    {
        public List<Post> posts { get; set; }
        public int totalResults { get; set; }
        public int moreResultsAvailable { get; set; }
        public string next { get; set; }
        public int requestsLeft { get; set; }
    }
}
