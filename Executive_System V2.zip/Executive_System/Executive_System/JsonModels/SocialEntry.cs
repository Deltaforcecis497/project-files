﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Executive_System.JsonModels
{
    public class SocialEntry
    {
        public int likes { get; set; }
        public int comments { get; set; }
        public int shares { get; set; }
    }
}
