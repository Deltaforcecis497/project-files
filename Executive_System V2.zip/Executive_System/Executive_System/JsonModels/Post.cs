﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Executive_System.JsonModels
{
    public class Post
    {
        public Thread thread { get; set; }
        public string uuid { get; set; }
        public string url { get; set; }
        public int ord_in_thread { get; set; }
        public string author { get; set; }
        public string published { get; set; }
        public string title { get; set; }
        public string text { get; set; }
        public string highlightText { get; set; }
        public string highlightTitle { get; set; }
        public string language { get;set; }
        public List<string> external_links { get; set; }
        public Entities entities { get; set; }
        public string rating { get; set; }
        public string crawled { get; set; }
    }
}


